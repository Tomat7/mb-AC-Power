# HDvalve
Simple valve start-stop control library

Used to control flow (speed of collection) of "product" on special devices. :-)
+ Max open time 60000 msec. If more the valve will be open continually.
+ Max close time 60000 msec. If more or (open_time < 1) the valve will be closed infinite.

P.S. Sorry, no example yet. :-(
