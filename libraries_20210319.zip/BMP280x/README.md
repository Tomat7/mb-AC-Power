# BMP280x
Another Arduino library for BMP280 pressure module.

* First of all try to find addreess of you module by **i2c scanner**.
(_Google for it, if don't keep it._)

* Than, see **examples** and edit it for correct I2C address.

